<!DOCTYPE html>

<html>
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body id="body">
  <div class="container">
    
    <form>
      <datalist>
        
      </datalist>
      <input type="submit">
    </form>
    
  </div>
  <script src="javascript.js"></script>
  <script>
    giveHrefDiv();
  </script>
</body>
</html>
