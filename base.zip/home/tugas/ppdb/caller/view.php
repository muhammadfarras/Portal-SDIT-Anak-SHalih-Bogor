<!DOCTYPE html>

<html>
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body id="body">
  <div class="container">
    
    <div class="header"></div>
    <div class="body">
    <?php
      while ($data = mysqli_fetch_assoc ($job)){
            
            $path = mysqli_fetch_assoc (getPathFromJob ($data['deskripsi']));
          
            echo "<div href=$path[path] name=job class=job id=job>$data[deskripsi]</div>";
            
        }

    ?>
    </div>
    
  </div>
  <script src="javascript.js"></script>
  <script>
    giveHrefDiv();
  </script>
</body>
</html>
