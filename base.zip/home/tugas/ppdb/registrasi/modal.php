<?php    
    
    function getList () {
        $connect = $GLOBALS['connect'];
         
    }
    
?>