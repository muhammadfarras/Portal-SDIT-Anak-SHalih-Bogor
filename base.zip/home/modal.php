<?php
    
    $data = getBiodataFromId ();
    $job = getJobFromId();
    
  
    

?>