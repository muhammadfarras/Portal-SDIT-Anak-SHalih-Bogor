<!DOCTYPE html>

<html>
<head>
    <title>Login SDIT Anak Shalih Bogor</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    
</head>
<body id="body">
  <div class="container">
    <form action="" method="post">
      <p>
        <span>Email <span id="warn-email" class="warn email"></span></span>
        <br>
        <input name="email" id="email" type="text" placeholder="Email antum" autocomplete="off">
        
      </p>
      <p>
        <span>Password <span id="warn-password" class="warn password"></span></span>
        <br>
        <input name="password" id="password" type="password" placeholder="Password antum">
      </p>
      <p>
        <input name="submit" id="submit" type="submit" value="Login">
      </p>
      <address>Berlum terdaftar ? <a id="daftar">Daftarkan email antum</a></address>
    </form>
  </div>
  <script src="javascript.js"></script>
  <script>
    isSubmitOk ();
    checkEmpty ();
    daftarEmail();
    isEmailRegistered ();
    isEmailAndPassRegistered ();
  </script>
</body>
</html>
