<?php

    function dataBiodata () {
        echo "oke";
    }
    
?>