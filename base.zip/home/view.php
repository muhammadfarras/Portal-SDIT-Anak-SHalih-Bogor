<!DOCTYPE html>

<html>
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body id="body">
  <div class="container">
    
    <div class="header">
      <table>
        <tr><th colspan=2>Biodata</th></tr>
        <tr><td><?php echo ucfirst ($data['nama_depan'])." ".ucfirst ($data['nama_belakang']); ?></td></tr>
        <tr><td><?php echo ($data['email'])?></td></tr>
      </table>
    </div>
    <div class="body">
      <h3>Akses Tugas</h3>
    <?php
    if (mysqli_affected_rows ($connect)){
      
      while ($data = mysqli_fetch_assoc ($job)){
            
            $path = mysqli_fetch_assoc (getPathFromJob ($data['deskripsi']));
          
            echo "<div href=$path[path] name=job class=job id=job>$data[deskripsi]</div>";
            
        }
    }
    else {
      echo "<span class=caution>Admin belum memberikan akses tugas</span>";
    }
    ?>
    </div>
    
  </div>
  <script src="javascript.js"></script>
  <script>
    giveHrefDiv();
  </script>
</body>
</html>
