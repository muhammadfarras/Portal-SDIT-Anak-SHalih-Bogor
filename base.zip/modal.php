<?php
require ("advance.php");
if(!empty ($_GET['email-terdaftar'])){
    
    if ( isEmailRegistered ($_GET['email']) ){
        echo "!";
    }
    
}

if (!empty ($_GET['email-pass'])){
    
    if (!isEmailAndPasswordRegistered ($_GET['email'],$_GET['password'])){
        echo "!";
    }
    
    
}



?>