<?php

require ("advance.php");

include ("control.php");
include ("view.php");
include ("cookie.php");

?>